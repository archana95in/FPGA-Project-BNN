# finn-hlslib [![Documentation Status](https://readthedocs.org/projects/finn-hlslib/badge/?version=latest)](https://finn-hlslib.readthedocs.io/en/latest/?badge=latest)


This repo contains the HLS library for hardware acceleration of Quantized Neural Network (QNN) using FINN. 

For more information please refer to the documentation available <a href="https://finn-hlslib.readthedocs.io" target="_blank"> here </a>. 

