#define WIDTH 8
#define NUM_REPEAT 4