#define NUM_CHANNELS 32
#define INPUT_WIDTH 4
#define OUTPUT_WIDTH 4
#define NUM_WORDS 4
#define NUM_REPEAT 1
#define OFFSET 2
#define SAT 1
